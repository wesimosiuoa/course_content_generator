import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Login from './pages/Login';
import SuperAdminDashboard from './pages/SuperAdminDashboard';
import DeptAdminDashboard from './pages/DeptAdminDashboard';
import FacultyDashboard from './pages/FacultyDashboard';
import StudentDashboard from './pages/StudentDashboard';
import PrivateRoute from './components/PrivateRoute';

function App() {
  return (
    <Router>
      <Toaster position="top-right" />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Navigate to="/login" />} />
        
        <Route path="/super-admin/*" element={
          <PrivateRoute role="super-admin">
            <SuperAdminDashboard />
          </PrivateRoute>
        } />
        
        <Route path="/dept-admin/*" element={
          <PrivateRoute role="dept-admin">
            <DeptAdminDashboard />
          </PrivateRoute>
        } />
        
        <Route path="/faculty/*" element={
          <PrivateRoute role="faculty">
            <FacultyDashboard />
          </PrivateRoute>
        } />
        
        <Route path="/student/*" element={
          <PrivateRoute role="student">
            <StudentDashboard />
          </PrivateRoute>
        } />
      </Routes>
    </Router>
  );
}

export default App;