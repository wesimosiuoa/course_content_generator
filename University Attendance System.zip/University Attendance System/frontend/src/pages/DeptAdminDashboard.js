import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import authService from '../services/auth';
import api from '../services/api';
import './Dashboard.css';

const DeptAdminDashboard = () => {
  const [sections, setSections] = useState([]);
  const [faculties, setFaculties] = useState([]);
  const [showAllocationForm, setShowAllocationForm] = useState(false);
  const [showStudentUpload, setShowStudentUpload] = useState(false);
  const [showTimetable, setShowTimetable] = useState(false);
  const [selectedSection, setSelectedSection] = useState(null);
  const [allocationData, setAllocationData] = useState({
    sectionId: '',
    subjectId: '',
    facultyId: ''
  });
  const [studentFile, setStudentFile] = useState(null);
  const [timetable, setTimetable] = useState([]);

  useEffect(() => {
    fetchSections();
    fetchFaculties();
  }, []);

  const fetchSections = async () => {
    try {
      const response = await api.get('/dept-admin/sections');
      setSections(response.data);
    } catch (error) {
      toast.error('Failed to fetch sections');
    }
  };

  const fetchFaculties = async () => {
    try {
      const response = await api.get('/dept-admin/faculties');
      setFaculties(response.data);
    } catch (error) {
      toast.error('Failed to fetch faculties');
    }
  };

  const handleAllocation = async (e) => {
    e.preventDefault();
    try {
      await api.post('/dept-admin/allocate-faculty', allocationData);
      toast.success('Faculty allocated successfully');
      setShowAllocationForm(false);
      fetchSections();
    } catch (error) {
      toast.error('Allocation failed');
    }
  };

  const handleStudentUpload = async (e) => {
    e.preventDefault();
    if (!studentFile) {
      toast.error('Please select a file');
      return;
    }

    const formData = new FormData();
    formData.append('file', studentFile);

    try {
      const response = await api.post('/dept-admin/students/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      toast.success(`Uploaded ${response.data.created.length} students`);
      setShowStudentUpload(false);
    } catch (error) {
      toast.error('Upload failed');
    }
  };

  const viewTimetable = async (sectionId) => {
    try {
      const response = await api.get(`/dept-admin/timetable/${sectionId}`);
      setTimetable(response.data);
      setSelectedSection(sectionId);
      setShowTimetable(true);
    } catch (error) {
      toast.error('Failed to fetch timetable');
    }
  };

  const updateSemesterDates = async (sectionId, startDate, endDate) => {
    try {
      await api.put(`/dept-admin/semester-dates/${sectionId}`, { startDate, endDate });
      toast.success('Semester dates updated');
      fetchSections();
    } catch (error) {
      toast.error('Update failed');
    }
  };

  return (
    <div className="dashboard">
      <div className="sidebar">
        <h2>Department Admin</h2>
        <ul>
          <li className="active">Dashboard</li>
          <li onClick={() => setShowStudentUpload(true)}>Upload Students</li>
          <li onClick={() => setShowAllocationForm(true)}>Allocate Faculty</li>
          <li>View Timetable</li>
          <li>Reports</li>
        </ul>
      </div>

      <div className="main-content">
        <div className="header">
          <h1>Department Admin Dashboard</h1>
          <p>Welcome, {authService.getCurrentUser()?.name}</p>
        </div>

        <div className="stats-grid">
          <div className="stat-card">
            <h3>Total Sections</h3>
            <p>{sections.length}</p>
          </div>
          <div className="stat-card">
            <h3>Total Faculties</h3>
            <p>{faculties.length}</p>
          </div>
        </div>

        {/* Sections List */}
        <div className="sections-list">
          <h2>Sections</h2>
          <table>
            <thead>
              <tr>
                <th>Section</th>
                <th>Semester</th>
                <th>Students</th>
                <th>Subjects</th>
                <th>Semester Dates</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sections.map(section => (
                <tr key={section._id}>
                  <td>{section.name}</td>
                  <td>{section.semester}</td>
                  <td>{section.students?.length || 0}</td>
                  <td>{section.subjects?.length || 0}</td>
                  <td>
                    {section.semesterStartDate ? 
                      new Date(section.semesterStartDate).toLocaleDateString() : 'Not set'} - 
                    {section.semesterEndDate ? 
                      new Date(section.semesterEndDate).toLocaleDateString() : 'Not set'}
                  </td>
                  <td>
                    <button onClick={() => viewTimetable(section._id)}>View Timetable</button>
                    <button onClick={() => {
                      const startDate = prompt('Enter start date (YYYY-MM-DD)');
                      const endDate = prompt('Enter end date (YYYY-MM-DD)');
                      if (startDate && endDate) {
                        updateSemesterDates(section._id, startDate, endDate);
                      }
                    }}>Update Dates</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Faculty Allocation Modal */}
        {showAllocationForm && (
          <div className="modal">
            <div className="modal-content">
              <h2>Allocate Faculty to Section</h2>
              <form onSubmit={handleAllocation}>
                <select
                  value={allocationData.sectionId}
                  onChange={(e) => setAllocationData({...allocationData, sectionId: e.target.value})}
                  required
                >
                  <option value="">Select Section</option>
                  {sections.map(section => (
                    <option key={section._id} value={section._id}>
                      {section.name} - Semester {section.semester}
                    </option>
                  ))}
                </select>
                
                <input
                  type="text"
                  placeholder="Subject ID"
                  value={allocationData.subjectId}
                  onChange={(e) => setAllocationData({...allocationData, subjectId: e.target.value})}
                  required
                />
                
                <select
                  value={allocationData.facultyId}
                  onChange={(e) => setAllocationData({...allocationData, facultyId: e.target.value})}
                  required
                >
                  <option value="">Select Faculty</option>
                  {faculties.map(faculty => (
                    <option key={faculty._id} value={faculty._id}>
                      {faculty.name}
                    </option>
                  ))}
                </select>
                
                <div className="modal-actions">
                  <button type="submit">Allocate</button>
                  <button type="button" onClick={() => setShowAllocationForm(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Student Upload Modal */}
        {showStudentUpload && (
          <div className="modal">
            <div className="modal-content">
              <h2>Upload Students</h2>
              <form onSubmit={handleStudentUpload}>
                <input
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={(e) => setStudentFile(e.target.files[0])}
                  required
                />
                <div className="modal-actions">
                  <button type="submit">Upload</button>
                  <button type="button" onClick={() => setShowStudentUpload(false)}>Cancel</button>
                </div>
              </form>
              <p className="info">Excel file columns: name, rollNo, email, semester, sectionId, batch</p>
            </div>
          </div>
        )}

        {/* Timetable Modal */}
        {showTimetable && (
          <div className="modal large">
            <div className="modal-content">
              <h2>Section Timetable</h2>
              <div className="timetable">
                {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => (
                  <div key={day} className="timetable-day">
                    <h3>{day}</h3>
                    {timetable.find(t => t.day === day)?.periods?.map((period, index) => (
                      <div key={index} className="period">
                        <span className="period-number">Period {period.periodNumber}</span>
                        <span className="period-time">{period.startTime} - {period.endTime}</span>
                        <span className="period-subject">{period.subject?.name}</span>
                        <span className="period-faculty">{period.faculty?.name}</span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
              <button onClick={() => setShowTimetable(false)}>Close</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DeptAdminDashboard;