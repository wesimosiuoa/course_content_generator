import React, { useState, useEffect } from 'react';
import { toast } from 'react-hot-toast';
import authService from '../services/auth';
import api from '../services/api';
import './Dashboard.css';

const FacultyDashboard = () => {
  const [mySections, setMySections] = useState([]);
  const [selectedSection, setSelectedSection] = useState(null);
  const [selectedSubject, setSelectedSubject] = useState(null);
  const [attendanceData, setAttendanceData] = useState([]);
  const [showAttendanceForm, setShowAttendanceForm] = useState(false);
  const [showMarksForm, setShowMarksForm] = useState(false);
  const [students, setStudents] = useState([]);
  const [attendanceRecords, setAttendanceRecords] = useState([]);

  useEffect(() => {
    fetchMySections();
  }, []);

  const fetchMySections = async () => {
    try {
      const response = await api.get('/faculty/my-sections');
      setMySections(response.data);
    } catch (error) {
      toast.error('Failed to fetch sections');
    }
  };

  const handleAttendanceMarking = async (e) => {
    e.preventDefault();
    
    const attendancePayload = {
      sectionId: selectedSection._id,
      subjectId: selectedSubject,
      date: e.target.date.value,
      period: {
        periodNumber: e.target.periodNumber.value,
        startTime: e.target.startTime.value,
        endTime: e.target.endTime.value
      },
      attendance: attendanceRecords
    };

    try {
      await api.post('/faculty/attendance', attendancePayload);
      toast.success('Attendance marked successfully');
      setShowAttendanceForm(false);
    } catch (error) {
      toast.error('Failed to mark attendance');
    }
  };

  const handleMarksSubmission = async (e) => {
    e.preventDefault();
    
    const marksPayload = {
      studentId: e.target.studentId.value,
      subjectId: selectedSubject,
      sectionId: selectedSection._id,
      internalMarks: e.target.internalMarks.value,
      examType: 'internal',
      semester: selectedSection.semester
    };

    try {
      await api.post('/faculty/marks', marksPayload);
      toast.success('Marks submitted successfully');
      setShowMarksForm(false);
    } catch (error) {
      toast.error('Failed to submit marks');
    }
  };

  return (
    <div className="dashboard">
      <div className="sidebar">
        <h2>Faculty Dashboard</h2>
        <ul>
          <li className="active">My Sections</li>
          <li>Attendance</li>
          <li>Internal Marks</li>
          <li>Assignments</li>
          <li>Timetable</li>
        </ul>
      </div>

      <div className="main-content">
        <div className="header">
          <h1>Faculty Dashboard</h1>
          <p>Welcome, {authService.getCurrentUser()?.name}</p>
        </div>

        <div className="sections-grid">
          {mySections.map(section => (
            <div key={section._id} className="section-card">
              <h3>{section.name}</h3>
              <p>Semester: {section.semester}</p>
              <p>Students: {section.students?.length || 0}</p>
              
              <div className="subjects-list">
                <h4>Subjects:</h4>
                {section.subjects?.map(subject => (
                  <div key={subject.subject?._id} className="subject-item">
                    <span>{subject.subject?.name}</span>
                    <div className="subject-actions">
                      <button onClick={() => {
                        setSelectedSection(section);
                        setSelectedSubject(subject.subject?._id);
                        setStudents(section.students);
                        setShowAttendanceForm(true);
                      }}>Mark Attendance</button>
                      <button onClick={() => {
                        setSelectedSection(section);
                        setSelectedSubject(subject.subject?._id);
                        setShowMarksForm(true);
                      }}>Submit Marks</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Attendance Form Modal */}
        {showAttendanceForm && (
          <div className="modal large">
            <div className="modal-content">
              <h2>Mark Attendance - {selectedSection?.name}</h2>
              <form onSubmit={handleAttendanceMarking}>
                <div className="form-row">
                  <input
                    type="date"
                    name="date"
                    required
                  />
                  <input
                    type="number"
                    name="periodNumber"
                    placeholder="Period Number"
                    required
                  />
                </div>
                <div className="form-row">
                  <input
                    type="time"
                    name="startTime"
                    placeholder="Start Time"
                    required
                  />
                  <input
                    type="time"
                    name="endTime"
                    placeholder="End Time"
                    required
                  />
                </div>

                <h3>Student Attendance</h3>
                <div className="attendance-list">
                  {students.map(student => (
                    <div key={student._id} className="attendance-item">
                      <span>{student.name} ({student.studentDetails?.rollNo})</span>
                      <select
                        onChange={(e) => {
                          const existing = attendanceRecords.findIndex(
                            r => r.studentId === student._id
                          );
                          if (existing > -1) {
                            const updated = [...attendanceRecords];
                            updated[existing].status = e.target.value;
                            setAttendanceRecords(updated);
                          } else {
                            setAttendanceRecords([
                              ...attendanceRecords,
                              { studentId: student._id, status: e.target.value }
                            ]);
                          }
                        }}
                        required
                      >
                        <option value="">Select Status</option>
                        <option value="present">Present</option>
                        <option value="absent">Absent</option>
                        <option value="late">Late</option>
                      </select>
                    </div>
                  ))}
                </div>

                <div className="modal-actions">
                  <button type="submit">Submit Attendance</button>
                  <button type="button" onClick={() => setShowAttendanceForm(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Marks Form Modal */}
        {showMarksForm && (
          <div className="modal">
            <div className="modal-content">
              <h2>Submit Internal Marks</h2>
              <form onSubmit={handleMarksSubmission}>
                <select name="studentId" required>
                  <option value="">Select Student</option>
                  {students.map(student => (
                    <option key={student._id} value={student._id}>
                      {student.name} ({student.studentDetails?.rollNo})
                    </option>
                  ))}
                </select>
                
                <input
                  type="number"
                  name="internalMarks"
                  placeholder="Internal Marks (0-100)"
                  min="0"
                  max="100"
                  required
                />
                
                <div className="modal-actions">
                  <button type="submit">Submit Marks</button>
                  <button type="button" onClick={() => setShowMarksForm(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FacultyDashboard;