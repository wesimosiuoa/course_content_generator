import React, { useState } from 'react';
import { toast } from 'react-hot-toast';
import api from '../services/api';
import './Dashboard.css';

const StudentDashboard = () => {
  const [rollNo, setRollNo] = useState('');
  const [attendance, setAttendance] = useState(null);
  const [marks, setMarks] = useState(null);
  const [percentage, setPercentage] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchAttendance = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await api.get(`/student/attendance/${rollNo}`);
      setAttendance(response.data);
      toast.success('Attendance fetched successfully');
    } catch (error) {
      toast.error('Failed to fetch attendance');
    } finally {
      setLoading(false);
    }
  };

  const fetchMarks = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await api.get(`/student/marks/${rollNo}`);
      setMarks(response.data);
      toast.success('Marks fetched successfully');
    } catch (error) {
      toast.error('Failed to fetch marks');
    } finally {
      setLoading(false);
    }
  };

  const fetchPercentage = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await api.get(`/student/percentage/${rollNo}`);
      setPercentage(response.data);
      toast.success('Percentage calculated successfully');
    } catch (error) {
      toast.error('Failed to calculate percentage');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="dashboard">
      <div className="sidebar">
        <h2>Student Portal</h2>
        <ul>
          <li className="active">Dashboard</li>
          <li>View Attendance</li>
          <li>View Marks</li>
          <li>Semester Percentage</li>
        </ul>
      </div>

      <div className="main-content">
        <div className="header">
          <h1>Student Dashboard</h1>
          <p>Enter your Roll Number to view details</p>
        </div>

        <div className="student-search">
          <form>
            <input
              type="text"
              placeholder="Enter Roll Number"
              value={rollNo}
              onChange={(e) => setRollNo(e.target.value)}
              required
            />
            <div className="search-actions">
              <button type="submit" onClick={fetchAttendance} disabled={loading}>
                Get Attendance
              </button>
              <button type="submit" onClick={fetchMarks} disabled={loading}>
                Get Marks
              </button>
              <button type="submit" onClick={fetchPercentage} disabled={loading}>
                Get Percentage
              </button>
            </div>
          </form>
        </div>

        {attendance && (
          <div className="results-section">
            <h2>Attendance Report</h2>
            <table>
              <thead>
                <tr>
                  <th>Subject</th>
                  <th>Code</th>
                  <th>Total Classes</th>
                  <th>Attended</th>
                  <th>Percentage</th>
                </tr>
              </thead>
              <tbody>
                {attendance.map((item, index) => (
                  <tr key={index}>
                    <td>{item.subject}</td>
                    <td>{item.code}</td>
                    <td>{item.totalClasses}</td>
                    <td>{item.attended}</td>
                    <td className={item.percentage < 75 ? 'low-attendance' : ''}>
                      {item.percentage}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {marks && (
          <div className="results-section">
            <h2>Internal Marks</h2>
            <table>
              <thead>
                <tr>
                  <th>Subject</th>
                  <th>Internal Marks</th>
                  <th>Exam Type</th>
                  <th>Faculty</th>
                </tr>
              </thead>
              <tbody>
                {marks.map((mark) => (
                  <tr key={mark._id}>
                    <td>{mark.subject?.name}</td>
                    <td>{mark.internalMarks || 'N/A'}</td>
                    <td>{mark.examType}</td>
                    <td>{mark.faculty?.name}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {percentage && (
          <div className="results-section">
            <h2>Semester Performance</h2>
            <div className="percentage-card">
              <div className="student-info">
                <p><strong>Name:</strong> {percentage.name}</p>
                <p><strong>Roll No:</strong> {percentage.rollNo}</p>
                <p><strong>Semester:</strong> {percentage.semester}</p>
              </div>
              <div className="percentage-display">
                <div className="percentage-circle">
                  <span>{percentage.percentage}%</span>
                </div>
                <div className="marks-details">
                  <p>Total Marks: {percentage.totalMarks} / {percentage.maxMarks}</p>
                  <p>Subjects: {percentage.totalSubjects}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StudentDashboard;