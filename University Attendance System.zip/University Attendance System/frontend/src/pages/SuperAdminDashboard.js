import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import * as XLSX from 'xlsx';
import authService from '../services/auth';
import api from '../services/api';
import './Dashboard.css';

const SuperAdminDashboard = () => {
  const [colleges, setColleges] = useState([]);
  const [showCollegeForm, setShowCollegeForm] = useState(false);
  const [collegeData, setCollegeData] = useState({
    name: '',
    code: '',
    address: '',
    contactEmail: '',
    contactPhone: ''
  });
  const [file, setFile] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchColleges();
  }, []);

  const fetchColleges = async () => {
    try {
      const response = await api.get('/super-admin/colleges');
      setColleges(response.data);
    } catch (error) {
      toast.error('Failed to fetch colleges');
    }
  };

  const handleCollegeSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/super-admin/colleges', collegeData);
      toast.success('College registered successfully');
      setShowCollegeForm(false);
      setCollegeData({ name: '', code: '', address: '', contactEmail: '', contactPhone: '' });
      fetchColleges();
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to register college');
    }
  };

  const handleFileUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      toast.error('Please select a file');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await api.post('/super-admin/bulk-upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      
      toast.success(`Created ${response.data.created.length} users`);
      if (response.data.errors.length > 0) {
        console.log('Errors:', response.data.errors);
        toast.error(`${response.data.errors.length} errors occurred`);
      }
    } catch (error) {
      toast.error('Upload failed');
    }
  };

  const handleLogout = () => {
    authService.logout();
    navigate('/login');
  };

  return (
    <div className="dashboard">
      <div className="sidebar">
        <h2>Super Admin</h2>
        <ul>
          <li className="active">Dashboard</li>
          <li onClick={() => setShowCollegeForm(true)}>Register College</li>
          <li>Bulk Upload</li>
          <li>Reports</li>
          <li onClick={handleLogout}>Logout</li>
        </ul>
      </div>

      <div className="main-content">
        <div className="header">
          <h1>Super Admin Dashboard</h1>
          <p>Welcome, {authService.getCurrentUser()?.name}</p>
        </div>

        <div className="stats-grid">
          <div className="stat-card">
            <h3>Total Colleges</h3>
            <p>{colleges.length}</p>
          </div>
          <div className="stat-card">
            <h3>Total Departments</h3>
            <p>{colleges.reduce((acc, college) => acc + (college.departments?.length || 0), 0)}</p>
          </div>
        </div>

        {showCollegeForm && (
          <div className="modal">
            <div className="modal-content">
              <h2>Register New College</h2>
              <form onSubmit={handleCollegeSubmit}>
                <input
                  type="text"
                  placeholder="College Name"
                  value={collegeData.name}
                  onChange={(e) => setCollegeData({...collegeData, name: e.target.value})}
                  required
                />
                <input
                  type="text"
                  placeholder="College Code"
                  value={collegeData.code}
                  onChange={(e) => setCollegeData({...collegeData, code: e.target.value})}
                  required
                />
                <input
                  type="text"
                  placeholder="Address"
                  value={collegeData.address}
                  onChange={(e) => setCollegeData({...collegeData, address: e.target.value})}
                />
                <input
                  type="email"
                  placeholder="Contact Email"
                  value={collegeData.contactEmail}
                  onChange={(e) => setCollegeData({...collegeData, contactEmail: e.target.value})}
                />
                <input
                  type="tel"
                  placeholder="Contact Phone"
                  value={collegeData.contactPhone}
                  onChange={(e) => setCollegeData({...collegeData, contactPhone: e.target.value})}
                />
                <div className="modal-actions">
                  <button type="submit">Register</button>
                  <button type="button" onClick={() => setShowCollegeForm(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="bulk-upload-section">
          <h2>Bulk Upload Users</h2>
          <form onSubmit={handleFileUpload}>
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={(e) => setFile(e.target.files[0])}
              required
            />
            <button type="submit">Upload</button>
          </form>
          <p className="info">Upload Excel file with columns: name, email, role, collegeId, departmentId, employeeId (for faculty)</p>
        </div>

        <div className="colleges-list">
          <h2>Registered Colleges</h2>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Code</th>
                <th>Contact Email</th>
                <th>Departments</th>
              </tr>
            </thead>
            <tbody>
              {colleges.map(college => (
                <tr key={college._id}>
                  <td>{college.name}</td>
                  <td>{college.code}</td>
                  <td>{college.contactEmail}</td>
                  <td>{college.departments?.length || 0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SuperAdminDashboard;