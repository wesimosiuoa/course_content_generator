const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const XLSX = require('xlsx');
const multer = require('multer');
const { authenticate, authorize } = require('../middleware/auth');
const User = require('../models/user');
const Department = require('../models/department');
const Section = require('../models/section');
const Subject = require('../models/subject');

const upload = multer({ dest: 'uploads/' });

// Bulk upload students
router.post('/students/upload',
  authenticate,
  authorize('dept-admin'),
  upload.single('file'),
  async (req, res) => {
    try {
      const workbook = XLSX.readFile(req.file.path);
      const sheetName = workbook.SheetNames[0];
      const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

      const results = {
        created: [],
        errors: []
      };

      for (const row of data) {
        try {
          // Check if student already exists
          const existingStudent = await User.findOne({ 
            'studentDetails.rollNo': row.rollNo 
          });

          if (existingStudent) {
            results.errors.push({ row, error: 'Student already exists' });
            continue;
          }

          // Create student
          const hashedPassword = await bcrypt.hash(row.rollNo, 10);
          const student = new User({
            name: row.name,
            email: row.email || `${row.rollNo}@university.edu`,
            password: hashedPassword,
            role: 'student',
            department: req.user.department,
            college: req.user.college,
            studentDetails: {
              rollNo: row.rollNo,
              semester: row.semester,
              section: row.sectionId,
              batch: row.batch
            }
          });

          await student.save();

          // Add student to section
          await Section.findByIdAndUpdate(row.sectionId, {
            $push: { students: student._id }
          });

          results.created.push(student);
        } catch (error) {
          results.errors.push({ row, error: error.message });
        }
      }

      res.json(results);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
);

// Allocate faculty to section
router.post('/allocate-faculty', authenticate, authorize('dept-admin'), async (req, res) => {
  try {
    const { sectionId, subjectId, facultyId } = req.body;

    const section = await Section.findById(sectionId);
    if (!section) {
      return res.status(404).json({ error: 'Section not found' });
    }

    // Check if subject already has faculty
    const subjectIndex = section.subjects.findIndex(
      s => s.subject.toString() === subjectId
    );

    if (subjectIndex > -1) {
      section.subjects[subjectIndex].faculty = facultyId;
    } else {
      section.subjects.push({
        subject: subjectId,
        faculty: facultyId
      });
    }

    await section.save();

    // Update faculty's subjects and sections
    await User.findByIdAndUpdate(facultyId, {
      $addToSet: {
        'facultyDetails.subjects': subjectId,
        'facultyDetails.sections': sectionId
      }
    });

    res.json(section);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update semester dates
router.put('/semester-dates/:sectionId', authenticate, authorize('dept-admin'), async (req, res) => {
  try {
    const { startDate, endDate } = req.body;
    
    const section = await Section.findByIdAndUpdate(
      req.params.sectionId,
      {
        semesterStartDate: startDate,
        semesterEndDate: endDate
      },
      { new: true }
    );

    res.json(section);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get section timetable
router.get('/timetable/:sectionId', authenticate, authorize('dept-admin'), async (req, res) => {
  try {
    const section = await Section.findById(req.params.sectionId)
      .populate('subjects.subject')
      .populate('subjects.faculty')
      .populate('timetable.periods.subject')
      .populate('timetable.periods.faculty');

    res.json(section.timetable);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;