const express = require('express');
const router = express.Router();
const Attendance = require('../models/attendance');
const Marks = require('../models/marks');
const User = require('../models/user');

// Get student attendance percentage
router.get('/attendance/:rollNo', async (req, res) => {
  try {
    const student = await User.findOne({ 'studentDetails.rollNo': req.params.rollNo });
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const attendance = await Attendance.find({ student: student._id })
      .populate('subject');

    // Calculate attendance percentage per subject
    const subjectAttendance = {};
    attendance.forEach(record => {
      const subjectId = record.subject._id.toString();
      if (!subjectAttendance[subjectId]) {
        subjectAttendance[subjectId] = {
          subject: record.subject,
          total: 0,
          present: 0
        };
      }
      subjectAttendance[subjectId].total++;
      if (record.status === 'present') {
        subjectAttendance[subjectId].present++;
      }
    });

    // Calculate percentages
    const result = Object.values(subjectAttendance).map(item => ({
      subject: item.subject.name,
      code: item.subject.code,
      totalClasses: item.total,
      attended: item.present,
      percentage: ((item.present / item.total) * 100).toFixed(2)
    }));

    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get student marks
router.get('/marks/:rollNo', async (req, res) => {
  try {
    const student = await User.findOne({ 'studentDetails.rollNo': req.params.rollNo });
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const marks = await Marks.find({ student: student._id })
      .populate('subject')
      .populate('faculty', 'name');

    res.json(marks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get semester percentage
router.get('/percentage/:rollNo', async (req, res) => {
  try {
    const student = await User.findOne({ 'studentDetails.rollNo': req.params.rollNo });
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const marks = await Marks.find({ 
      student: student._id,
      examType: 'internal'
    }).populate('subject');

    // Calculate semester percentage
    let totalMarks = 0;
    let maxMarks = 0;

    marks.forEach(mark => {
      totalMarks += mark.internalMarks || 0;
      maxMarks += 100; // Assuming each subject max is 100
    });

    const percentage = maxMarks > 0 ? (totalMarks / maxMarks) * 100 : 0;

    res.json({
      rollNo: req.params.rollNo,
      name: student.name,
      semester: student.studentDetails.semester,
      totalSubjects: marks.length,
      totalMarks,
      maxMarks,
      percentage: percentage.toFixed(2)
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;