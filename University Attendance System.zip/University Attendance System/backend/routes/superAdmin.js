const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const XLSX = require('xlsx');
const multer = require('multer');
const { authenticate, authorize } = require('../middleware/auth');
const College = require('../models/college');
const Department = require('../models/department');
const User = require('../models/user');

const upload = multer({ dest: 'uploads/' });

// Register college
router.post('/colleges', authenticate, authorize('super-admin'), async (req, res) => {
  try {
    const college = new College(req.body);
    await college.save();
    res.status(201).json(college);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Bulk upload department admins and faculties
router.post('/bulk-upload', 
  authenticate, 
  authorize('super-admin'),
  upload.single('file'),
  async (req, res) => {
    try {
      const workbook = XLSX.readFile(req.file.path);
      const sheetName = workbook.SheetNames[0];
      const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

      const results = {
        created: [],
        errors: []
      };

      for (const row of data) {
        try {
          // Hash password
          const hashedPassword = await bcrypt.hash(row.password || 'default123', 10);
          
          // Create user
          const user = new User({
            name: row.name,
            email: row.email,
            password: hashedPassword,
            role: row.role,
            college: row.collegeId,
            department: row.departmentId,
            facultyDetails: row.role === 'faculty' ? {
              employeeId: row.employeeId
            } : undefined
          });

          await user.save();
          results.created.push(user);
        } catch (error) {
          results.errors.push({ row, error: error.message });
        }
      }

      res.json(results);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
);

// Get all colleges
router.get('/colleges', authenticate, authorize('super-admin'), async (req, res) => {
  try {
    const colleges = await College.find().populate('departments');
    res.json(colleges);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;