const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const Attendance = require('../models/attendance');
const Marks = require('../models/marks');
const Section = require('../models/section');
const User = require('../models/user');

// Mark attendance
router.post('/attendance', authenticate, authorize('faculty'), async (req, res) => {
  try {
    const { sectionId, subjectId, date, period, attendance } = req.body;

    const attendanceRecords = await Promise.all(
      attendance.map(async (record) => {
        const attendanceRecord = new Attendance({
          student: record.studentId,
          subject: subjectId,
          section: sectionId,
          faculty: req.user._id,
          date: new Date(date),
          period,
          status: record.status
        });

        return attendanceRecord.save();
      })
    );

    res.json(attendanceRecords);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Submit internal marks
router.post('/marks', authenticate, authorize('faculty'), async (req, res) => {
  try {
    const { studentId, subjectId, sectionId, internalMarks, assignments, examType } = req.body;

    const marks = new Marks({
      student: studentId,
      subject: subjectId,
      section: sectionId,
      faculty: req.user._id,
      internalMarks,
      assignments,
      examType,
      semester: req.body.semester
    });

    await marks.save();
    res.status(201).json(marks);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get faculty's sections
router.get('/my-sections', authenticate, authorize('faculty'), async (req, res) => {
  try {
    const sections = await Section.find({
      'subjects.faculty': req.user._id
    })
    .populate('subjects.subject')
    .populate('students');

    res.json(sections);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;