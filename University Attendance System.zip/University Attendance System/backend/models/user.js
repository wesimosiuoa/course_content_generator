const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['super-admin', 'dept-admin', 'faculty', 'student'],
    required: true
  },
  department: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Department'
  },
  college: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'College'
  },
  facultyDetails: {
    employeeId: String,
    subjects: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subject'
    }],
    sections: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Section'
    }]
  },
  studentDetails: {
    rollNo: {
      type: String,
      unique: true,
      sparse: true
    },
    semester: Number,
    section: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Section'
    },
    batch: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('User', userSchema);